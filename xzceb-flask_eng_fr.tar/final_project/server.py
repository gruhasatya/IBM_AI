from machinetranslation import translator
from flask import Flask, render_template, request
import json
import machinetranslation

app = Flask("Web Translator")

@app.route("/englishToFrench")
def englishToFrench():
    textToTranslate = request.args.get('textToTranslate')
    englishtranslation = language_translator,translate(
        text=englishText,
        model_id='en-fr'
    ).get-result()
    return frenchtranslation.get("translations")[0].get("translation")
    return "Translated text to French"

@app.route("/frenchToEnglish")
def frenchToEnglish():
    textToTranslate = request.args.get('textToTranslate')
    # Write your code here
    englishtranslation = language_translator,translate(
        text=frenchText,
        model_id='fr-en'
    ).get-result()
    return "Translated text to English"

@app.route("/")
def renderIndexPage():
    return index.html

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
