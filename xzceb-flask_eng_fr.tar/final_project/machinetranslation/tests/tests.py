import unittest
from translator import englishToFrench, frenchToEnglish

class TestEnglishTofrench(unittest.TestCase):
    def test(self):
        self.assertEqual(englishToFrench('hello'), 'Bonjour')
        self.assertEqual(englishToFrench(), )

class TestFrenchToEnglish(unittest.TestCase):
    def test(self):
        self.assertEqual(frenchToEnglish('Bonjour'), 'Hello')
        self.assertEqual(frenchToEnglish(), )

unittest.main()